from django.apps import AppConfig


class ModuleUserConfig(AppConfig):
    name = 'module_user'
