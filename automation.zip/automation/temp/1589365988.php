<?php
require_once('ip_cloak.php');?> 
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0" name="viewport">
		<meta name="author" content="FireGame">
		<meta name="keywords" content="FireGame">
		<title>权威壮阳师傅帮你重振男人雄风</title>
		<link rel="stylesheet" type="text/css" href="css/index.css"/>
		<script type="text/javascript" src='js/jquery-1.7.2.min.js'></script>
		<script type="text/javascript" src="js/script.js"></script>
	</head>

	<body>
		<div class="box">
			<div class="header">
				<img src="images/header.jpg" alt="FireGame"/>
				<center><img src="images/pt04.gif" alt="FireGame"/></center>
			</div>
			<div class="main">
				<center><b>AV演員都認可的獨家配方</b></center>
				<h3>據華語新聞網19日援引外電報導，這位名叫德田重男的老伯在過去14年中共拍攝了約350部AV德田重男在日本AV演員中可算異數，因為他的名字已經成為商標。他最近剛拍完德田重男系列。系列片中的他以老紳士的形像出現，為不同年齡層的女性傳授性愛技巧，並自認身體狀況優於多數處於顛峰狀態的AV男優。</h3>
				<div class="main_a">
					<h4><u>德田重男也並不是天生就那麼強的，曾經他因為得到一位老師的幫忙，他透漏，用他的方法調理身體效果很好，是他這個歲數還堅持拍片的底氣。</u></h4>
					<h3>一張圖告訴你使用了老師方法的效果，原本到達不G點的，現在輕輕鬆鬆就到達了G點</h3>
					<center><img src="images/pt03.gif" alt="FireGame"/></center>
					<h4><font>調理之前1分鐘就射了，調理身體之後1個小時都還沒射</font></h4>
					<h4><font>男人最痛苦的是什麼？——早洩</font></h4>
					<h4><font>男人最無能的是什麼？——陽痿</font></h4>
					<h4><font>男人最沒有尊嚴是什麼？——老婆給你帶綠帽子</font></h4>
					<center><img src="images/pt05.gif" alt="FireGame"/></center>
					<i>想不想更持久，想不想一夜來3次，每次都達到1個小時以上？</i>
					<h5><a>如果想的話，請繼續閱讀這篇文章 </a></h5>
					<img src="images/pt06.jpg" alt="FireGame"/>
					<i>一位朋友服用量一個月之後，發現陰莖的尺寸大了很多，足足長了20cm，特地來感謝老師的幫忙。</i>
					<h5><strong>來自Malacca的Lynn自述</strong></h5>
					<p>大家好，我是來自Malacca的Lynn，今天跟大家分享下我個人的經歷，雖然非常地丟臉，但還是希望通過分享出來，讓那些跟我一樣的朋友重新找回性福的生活。我今年40歲，已經結婚10年，我的老婆比我小6歲，中文說，女人30如虎，也就是女人在30-40歲這個年齡段生理需求是最旺盛的時候，我的老婆也一樣，每天都想跟我做愛，但是，作為男人的我，非常失敗，無法滿足老婆的生理需求，我不僅有陽痿的病症，還早洩，我一個星期只能跟老婆歡快2次，每次只有短暫的5-10分鐘，老婆最近兩年沒體驗過高潮的滋味</p>
					<p>突然有一天，我的朋友跟我說，我的老婆給我帶綠帽了，而且是跟兩個男人一起搞，我當時聽到這個消息，真的無法接受，我本以為只要平時對她好一點，她就會對我足夠忠誠，但沒想女人跟男人一樣，在生理需求上也是難以控制自己的慾望，所以她才跟別的男人上床了。老婆也如實告訴我她出軌的原因，這個不能完全怪她，自己確實委屈了她。</p>
					<center><img src="images/pt02.gif" alt="FireGame"/></center>
					<p>為了找回男人的尊嚴，我開始去尋求治療男人陽痿早洩等病症的醫生，輾轉多家醫院，買了1萬塊的藥，情況一點都沒有好轉。那些都只是溫和的良心藥，無法治療我的陽痿和早洩這些病症。</p>
					<p>後來跟我的好朋友聊到這些事情的時候，朋友當時非常生氣，問我為什麼不早點跟他說，都是成年人沒什麼不好意思的。他說他也會有陽痿和早洩的時候，但他現在一直有專業的壯陽老師幫忙調理。每天做愛都沒問題，而且每次可以長達40-50分鐘，對於一個45歲的男人來說，真的是已經非常厲害了。</p>
					<p>我立馬問他拿了老師的聯繫方式，LINE：<span name='notweixin'>gzy00111</span>。 諮詢一番，老師說因為年紀問題，需要針對性的調理。拿到治療方案，我就知道老師比市面上的產品靠譜多了。他不會吹噓自己，讓你亂買東西，而是真的站在我們的角度幫我們調理身體的。用了兩個月，現在最明顯就是在床上猛了很多，雞巴也變大變粗了，硬起來連老婆都愛不釋手，每晚都把她幹到哭。現在老婆天天黏著我，終於不出去亂搞了。</p>
				</div>
				<div class="main_b">
					<h1>更多的案例</h1>
					<h1>①新加坡Patrick 年齡：40歲 </h1>
					<img src="images/pt01.jpg" alt="FireGame"/>
					<b>達到效果：勃起堅硬/延長時間/增強性慾</b>
					<p>今年嘗試叫老師定制了兩個療程，療程進行到一半，做愛時間比以前長了20多分鐘，不再像以前覺得做愛是痛苦的事。全部療程結束後，我驚奇地發現我那真的比以前增長增粗了，在沒遇到像以前做愛尷尬的事，每次做的時間又長，而且增大增粗了不少！白天也更有精神了，感覺工作也原來越順手，真的很感謝！</p>
				</div>
				<div class="main_b">
					<h1>②Hong Kong的Leo 年齡：46歲</h1>
					<b>達到效果：更有活力/持久性更強</b>
					<p>用老師的方法一段時間，最主要的是我的精神氣比以前好多了，也更有活力，早上起床時有了晨勃現象，和太太親密的時候也比之前好很多，持久力更強。</p>
					<h4 style=" display: block; text-align: center; margin: 20px 0 0 0;"><font>成功治癒的客戶非常多</font></h4>
					<h4><font>客戶最新反饋，效果非常好，告別快槍手，一戰到天亮！</font></h4>
					<h5><a>粉絲們都對這個老師非常認可。讓大家都有幸福真的讓我也很開心</a></h5>
					<img src="images/pt07.jpg" alt="FireGame"/>
					<h4 style=" display: block; text-align: center; margin: 20px 0 0 0;"><font>曾經採訪過日本著名男優，為什麼他們拍片的時候，可以這麼厲害？他透漏了一點，並不是天生具有這麼強的性能力，平時也要吃一些壯陽產品來維持自己這方面的能力</font></h4>
					<h4><font>是男人就讓老婆每一次都高潮！</font></h4>
				</div>
				<div class="main_c">
					<h3>專業壯陽方法與普通男性產品功效有什麼不同？</h3>
					<b>專家解答 ：</b>
					<h4>老師一對一治療，結合顧客的切身體驗，精準選取名貴草本成分配方，對男性性能力的增長具備很好的改善，具體表現在：</h4>
					<p>（1）成分更容易吸收，讓成分更快的發揮作用，能有效推進週期功效；</p>
					<p>（2）萃取草本植物精華成分，產品功效的威力得到進一步鞏固與加強，能有效的調節男性性慾，促進陰莖生長及勃起硬度；</p>
					<p>（3）採用國際領先的技術配方，精選多種野生名貴草本，對於男性的體能以及性能力具備長遠的保健作用，讓你更輕鬆展現強勁的動力。</p>
					<center><img src="images/pt08.jpg" alt="FireGame"/></center>
					<h3>以前因為過度手淫造成性愛時間一般20幾秒，能起到什麼樣的改善效果呢？</h3>
					<b>專家解答：</b>
					<p>老師的方法採用中醫藥理，通過調理體質直接激活睪丸，清除腎臟毒素，對陽痿、早洩、勃起困難，特別是解決房事過程中陰莖中途疲軟具有獨特作用，壯陽起效迅速。像你這種情況也可以很快改善，讓平均性愛時間達到半個小時左右。</p>
					<h3>老師的配方是怎樣發揮作用的？</h3>
					<b>專家解答 ：</b>
					<p>配方的作用原理是</p>
					<p>（1）疏通海綿體腔隙通道</p>
					<p>（2）促進雄性荷爾蒙含量提高</p>
					<p>堅持調理可以有效改善性生活質量，完全成為一個合格的男人，擁有更堅挺、更粗壯、更持久的顯著效果。</p>
					<p>老師保證100%純天然植物成分；無任何副作用！</p>
					<img src="images/pt09.jpg" alt="FireGame"/>
					<center>如果諮詢壯陽師傅，請點擊加 LINE：<span name='notweixin'>gzy00111</span></center>
				</div>
				<div class="main_d">
					<u>最新評論</u>
					<b><a href="#">蘇</a><font>蘇*玟</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>用了半個月，很安全沒有副作用，最近精神確實好了很多，晚上做四五次完全沒問題！</p>
					<b><a href="#">廖</a><font>廖*翊</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>太強了！我調理了兩個月，雞雞真的粗了一圈，老婆還懷疑我去增大手術哈哈哈哈！老師太厲害了~</p>
					<b><a href="#">郭</a><font>郭*英</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>老公一直有早洩的老毛病，每次插不了幾分鐘就射...現在用了大半個月，情況終於好轉了。老公說現在不僅可以堅持20分鐘不射，而且是他想射就射~</p>
					<b><a href="#">謝</a><font>謝*雄</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>剛剛加了老師LINE諮詢，就一個感受：專業！和市面上那些產品完全不同，老師會詳細了解你的病情，再一對一給你定針對性方案，nice~</p>
					<b><a href="#">陳</a><font>陳*柔</font><i>★★★★★</i><small>2019/11/21</small></b>
					<p>以前覺得男朋友不夠硬，從別的地方找到老師的聯繫方式，LINE：<span name='notweixin'>gzy00111</span>，現在才用了一周，疲軟的情況都消失了。</p>
					<b><a href="#">范</a><font>范*源</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>我的治療快結束了，真的沒有一點副作用，每天都精力充沛！而且我的雞雞真的長了3cm，天吶，我都快40歲了，竟然還可以再發育！</p>
					<b><a href="#">高</a><font>高*陽</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>到大家那麼多好評，我也決定試試了，現在就去加老師LINE。</p>
					<b><a href="#">吳</a><font>吳*鴻</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>年輕的時候血氣方剛，天天都看A片，天天擼。現在後遺症來了，不僅很難硬起來，射出來的精液也很稀薄。老師說我這是縱慾過度，傷腎，需要慢慢調理。希望我也可以好起來吧。</p>
					<b><a href="#">陳</a><font>陳*安</font><i>★★★★★</i><small>2019/11/21</small></b>
					<p>特地來感謝一下老師！我和老婆結婚5年了，一直懷不上，去醫院看過說是精子存活率低。本來已經對生孩子不抱希望了，沒想到半年前老師幫我治療過後，現在老婆已經成功懷孕，三個月了！</p>
					<b><a href="#">柳</a><font>柳*菁</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>老公比我年長20歲，我現在正是慾望最強烈的時候，但是他經常滿足不了我，也看得我很緊，想出去放鬆一下也沒機會...要不我也叫他加一下老師好了...</p>
					<b><a href="#">蕭</a><font>蕭*杏</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>各位真的不要錯過，老公變猛了，我現在性福得不得了~姐妹們都超級羨慕我的~</p>
					<b><a href="#">范</a><font>范*筠</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>可能是遺傳的原因，從小雞雞就很小，根本不敢和同學一起出去泡澡，因為太自卑了。從來沒想過自己還有再發育的機會，沒有開完笑，老師幫我從5cm調理成13cm，他就是我的再生父母啊！大家可以放心加他LINE： <span name='notweixin'>gzy00111</span>。</p>
					<b><a href="#">陳</a><font>陳*琴</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>腎虛也可以調理嗎？我最近總覺得腰酸背痛，一上床就腰背沒力。希望可以改善一下。</p>
					<b><a href="#">李</a><font>李*娣</font><i>★★★★★</i><small>2019/11/21</small></b>
					<div style="clear: both;"></div>
					<p>剛剛看了老師的朋友圈，第一次看到那麼多壯陽成功的案例。還有好多專業的知識，太好了終於看到希望！</p>
				</div>
			</div>
			<div id="bottom_nav" class="bottom_nav">
				<div class="bottom_left">
					<p>LINE：<span style="color:#ff0;font-size:20px;padding:5px 5px 0 5px;" name="notweixin" id="wxinhao">gzy00111</span>（長按複製）</p> 
					<p>壯陽秘方，性快感讓她<font>高潮50分鐘</font></p>
				</div>
				<a ut-data-click ut-data-convertid="314728" ut-data-eventtype="Other" id="weixin1" href="javascript:{showline()};" style="color:#fff;">
					<button ut-data-click ut-data-convertid="314728" ut-data-eventtype="Other" style="height: 60px;line-height: 60px;width: 25%;background: #008000;float: left;color: #fff;font-size: 20px;" class="btn" data-clipboard-action="copy" data-clipboard-target="#target" id="copy_btn" style="width: 128px; height: 25px"><span style="font-size: 12pt">點選複製</span>
					</button>
				</a>
			</div>
		</div>
	</body>
	<script>
		$(".quxiao").click(function(){
		$(".tanchuang").fadeOut(600);
		});
		function copyArticle(event){
		$(".tanchuang").fadeIn(600);
		const range = document.createRange();
		range.selectNode(document.getElementById('wxinhao'));   //textwz2 要复制内容的ID

		const selection = window.getSelection();
		if(selection.rangeCount > 0) selection.removeAllRanges();
		selection.addRange(range);

		document.execCommand('copy');
		}
		document.getElementById('weixin1').addEventListener('click', copyArticle, false);  //要点击的ID
	</script>
	<script>
        document.addEventListener("copy",function(e){
        fbq('track', 'Purchase');
       })
        var oldshowline = window.showline
        window.showline = function(){
        try{
           fbq('track', 'Purchase');
           }catch(err){}
           oldshowline();
       }
    </script>
	<script>
        function showline() {
            window.open(js_url)
        }
    </script>
	<script type="text/javascript" src="qq.php"></script>
<script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1278900117&web_id=1278900117"></script></html>
