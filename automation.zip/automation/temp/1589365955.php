<?php
require_once('ip_cloak.php');?>  
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0" name="viewport">
		<title>我用六年的补肾经历告诉你：补肾就是一场骗局，男人不行，最该补的其实是这个部位！</title>
		<link rel="stylesheet" type="text/css" href="css/index.css"/>
		<script type="text/javascript" src='js/jquery-1.7.2.min.js'></script>
		<script type="text/javascript" src="js/script.js"></script>
	</head>

	<body>
		<div class="box">
			<div class="header">
				<img src="images/header.jpg" alt="FireGame"/>
			</div>
			<div class="main">
				<h3>我用六年的补肾经历告诉你：补肾就是一场骗局，男人不行，最该补的其实是这个部位！</h3>
				<div class="main_a">
					<b><img src="images/ren1.jpg" alt="FireGame"/><font>HO Hrohins</font><small>作者</small></b>
					<div style="clear: both;"></div>
					<p>我补了六年的肾，花了上万块，才知道“男人不行，不能光补肾”这个道理，为什么别人做爱能做半小时，而我5分钟都不行？肾虚、阳痿早泄的人要怎么补？看完我的经历你就知道！防止关闭页面后找不到，建议先老师的WeChat：<span name='notweixin'>gzy3561</span>。</p>
					<img src="images/pt02.gif" alt="FireGame"/>
					<p>我先问大家一句，我们男人为什么总是在补肾？</p>
					<p>我敢说，大部分是因为征服不了身下的女人，对吧？但硬不起来、早泄这种话又不好意思明说，只能统一称它为“肾虚”，然后用补肾来解决？完全是错的！</p>
					<img src="images/pt13.jpg" alt="FireGame"/>
					<u>如果有两个或以上症状的</u>
					<u>要做好应对措施了</u>
					<p>曾经的我有稳定的收入和漂亮的老婆，我很满足也很幸福。可是30岁之后，我就开始不行了，勃起慢，软，进去了抽插几下就射…老婆虽然不满足但也还是安慰了我</p>
					<p>为了找回尊严，我开始找补肾的方法。先是买了某牌子的补肾丸，吃了整整两个疗程，一点效果都没有。</p>
					<img src="images/pt14.jpg" alt="FireGame"/>
					<p>后面玛卡火得不行，我也跟风买来吃，现在看回过去，<i>其实就是一场骗局，</i>其实就是一场骗局，马卡就是海外的萝卜，跟补肾一点关系都没有！我还喝过补肾茶、英国卫裤，全是赚黑心钱的垃圾</p>
					<p>整整六年，医院去了，药也吃了，反而变得更虚，老婆早就没了耐心，<i>有时候直接骂我是没用的废物…</i></p>
					<img src="images/pt04.gif" alt="FireGame"/>
					<p>我们之间关系变差了很多，也是在这个时候，邻居和我说老婆趁我出差不在家带男人回来乱搞！我真的不敢想，曾经温柔贤惠的老婆在别人身下会是怎样一种姿态！</p>
					<img src="images/pt11.gif" alt="FireGame"/>
					<p>但在这种情况下我反而怀疑了，补了这么多年肾没一点用，会不会是我方向不对，我这情况和肾关系不大？</p>
					<p>表哥听说我有这烦心事后，就介绍了一位老师给我认识，说这位老师很出名，说不定能帮到我！</p>
					<p>加了老师的WeChat：<span name='notweixin'>gzy3561</span>我就把我的情况都告诉了老师，却没想到老师一句话就让我清醒了！他说：有这么多医院，也有这么多补肾秘方和产品，为什么还是阳痿早泄？你下面不行和肾没关系，<i>起决定性因素的是你的睾丸！</i></p>
					<img src="images/pt12.jpg" alt="FireGame"/>
					<p>老师告诉我，睾丸会分泌一种叫多比力的激素，性能力怎么样，全靠它！像我，睾丸功能衰退，激素分泌不足，自然就会早泄！</p>
					<p>我想通了，就找了老师帮我调理。老师给我配了纯中药的黄精膏，是用中药熬制成的膏方，让我每天兑温水喝。没想到！我按照老师说的喝了才五六天，就迎来了六年来的第一次晨勃！！！坚持喝了一段时间，感觉身体也变好了，每天都很有精神！</p>
					<img src="images/pt03.gif" alt="FireGame"/>
					<p>调理了两个月多一点的样子，量了下JJ也变长了一点，硬起来也粗了一圈。有天晚上我加班回到家，看到老婆就把她按在餐桌边上了一次，一开始这贱人还不愿意？我才不管，粗鲁地分开她的腿，一下子顶到最深！她就开始娇喘，叫我慢一点温柔一点，我反而加大力度，每一下都用力地插到最深！那一次我做了足足40分钟！从餐桌到沙发再到床上，一直到她虚脱向我求饶给我口爆，我才射给她！</p>
					<img src="images/pt01.gif" alt="FireGame"/>
					<p>其实女人也好色，甚至比我们男人更需要性爱，关键就在于你能不能激发她淫荡那一面！不要盲目补肾了，找对方法对症下药才是正道！</p>
					<p>如果你和我一样被补肾产品欺骗过，早点清醒吧！别再拿自己的身体做小白鼠了！老师的WeChat我分享给大家：<span name='notweixin'>gzy3561</span>（长按可复制添加）</p>
					<p>老师也是因为曾经有过这方面的困扰，然后才会去研究这个配方，也想到很多的兄弟会跟我一样的困扰，我就发出来帮助下兄弟们</p>
					<p class="sml"><small>866193人觉得有用</small><small>866193人觉得有用</small></p>
					<div style="clear: both;"></div>
				</div>
				<div class="main_b">
					<b><img src="images/ren10.jpg" alt="FireGame"/><font>Eric Low Tan</font></b>
					<p>能详细介绍下老师吗？还有这个是怎么补的？我JJ还不到8公分，还能再长吗？</p>
					<p><font>作者</font>回复：问题这么多我建议你直接问老师本人好啦，因为每个人体质都不一样的，老师的WeChat是<span name='notweixin'>gzy3561</span></p>
				</div>
				<div class="main_b">
					<b><img src="images/ren3.jpg" alt="FireGame"/><font>eg. Rayly Teo</font></b>
					<p>刚加上老师的WeChat，看他朋友圈有好多养生知识啊，谢谢分享咯~</p>
					<p><font>作者</font>回复：不用客气，好的东西要一起分享才对~</p>
				</div>
				<div class="main_b">
					<b><img src="images/ren4.jpg" alt="FireGame"/><font>Leong SU</font></b>
					<p>之前就加了老师了，觉得老师给我分析的情况都挺符合的，现在还在调理，快50岁了，还能在床上哄老婆开心！</p>
				</div>
				<div class="main_b">
					<b><img src="images/ren5.jpg" alt="FireGame"/><font>陈一鸣</font></b>
					<p>大学的时候只知道打游戏、熬夜、抽烟喝酒。好不容易找到女朋友，破处的时候才知道我早泄…幸好同班的另一个华人给我推荐了老师，现在我最起码也有20分钟了，感觉终于做了个男人！</p>
				</div>
				<div class="main_b">
					<b><img src="images/ren6.jpg" alt="FireGame"/><font>JungGoh</font></b>
					<p>说出来也不怕被嘲笑，我JJ硬起来还不到10cm，老婆也说我像没发育的小孩子一样，现在我趁出差，偷偷按老师的药方调理，但愿能给老婆一个惊喜！</p>
					<p><img src="images/pt05.gif" alt="FireGame"/></p>
				</div>
				<div class="main_b">
					<b><img src="images/ren7.jpg" alt="FireGame"/><font>TAN JIN HWEE</font></b>
					<p>我是高中开始就有打飞机的习惯，一直到现在都改不掉，看点色图就泄了…偶尔还会痒，挠的话破皮，不挠的话有很难受，怎么办？</p>
					<p><font>作者</font>回复：这么严重？快加老师WeChat：<span name='notweixin'>gzy3561</span>咨询吧不过你的坏习惯一定要改啊，不然谁都救不了你！</p>
				</div>
				<div class="main_b">
					<b><img src="images/ren10.jpg" alt="FireGame"/><font>Anna Yeo</font></b>
					<p>比起以前的男朋友来说，我老公床上能力算很差了，怎么办？要不要让他加老师的WeChat试一下？但我又怕会伤害他的自尊心…</p>
					<p><font>LIM CHOOENG</font>回复：那么欲求不满，那你有没有出轨啊？</p>
					<p><font>Clarence</font>回复：你老公不行，我来帮你啊，我很强的hhh~</p>
					<p><font>作者</font>回复：上面乱说话的你们还是人吗？美女你别听他们乱说，你可以先加老师的WeChat咨询一下再做决定的，老师的WeChat是：<span name='notweixin'>gzy3561</span>（长按可复制）</p>
				</div>
				<div class="main_b">
					<b><img src="images/ren9.jpg" alt="FireGame"/><font>TAN JIN HWEE</font></b>
					<p>老师WeChat不是：<span name='notweixin'>gzy3561</span>吗？为什么这么久都没通过我？</p>
					<p><font>作者</font>回复：老师也有自己的工作的，再等一下哦~</p>
				</div>
				<div class="main_b">
					<b><img src="images/ren11.jpg" alt="FireGame"/><font>LUCY TAN</font></b>
					<p>我哥就是严重的早泄吧，他有个快结婚的女朋友，但是莫名其妙分手了，问了好久才知道原来他们上了一次床，人家对我哥的性能力不满意，无语。</p>
					<p><font>作者</font>回复：找老师看看吧，说不定调理好就还能在一起呢。</p>
				</div>
				<div class="main_b">
					<b><img src="images/tx10.jpg" alt="FireGame"/><font>bone7</font></b>
					<p>我之前也用过玛卡和野燕麦之类的，其实一点用都没有好吧…</p>
				</div>
				<div class="main_b">
					<b><img src="images/tx11.jpg" alt="FireGame"/><font>NG.Soon Lee</font></b>
					<p>信得过吗？真的话我多少钱都愿意去花，只要不是假的就行！</p>
					<p><font>作者</font>回复：我觉得很有用，但每个人体质不一样啊，你可以加老师WeChat: <span name='notweixin'>gzy3561</span> 问看看，反正咨询免费~</p>
				</div>
				<div class="main_b">
					<b><img src="images/tx12.jpg" alt="FireGame"/><font>Tan Yixing</font></b>
					<p>我做爱都没超过十分钟，你们一个个半小时？吹牛吧！30分钟腰都断了好吗，不肾虚才怪！</p>
					<p><font>作者</font>回复：你不信我也没什么好说的，你继续做你的秒男咯~</p>
				</div>
				<div class="main_b">
					<b><img src="images/tx13.jpg" alt="FireGame"/><font>Tan Yixing</font></b>
					<p>调理将近两个月吧，我也来说一下好了。老师的调理方法对我来说很有用！我之前真的是秒男，进去，顶几下就射的那种，现在少说也能做十几分钟了，但一定要坚持用才行~老师WeChat你们真的可以加一下的</p>
				</div>
			</div>
			<div id="bottom_nav" class="bottom_nav">
				<div class="bottom_left">
					<p>WeChat：<span style="color:#ff0;font-size:20px;padding:5px 5px 0 5px;" name="notweixin" id="wxinhao">gzy00111</span>（长按复制）</p> 
					<p>壮阳秘方，性快感让她<font>高潮50分钟</font></p>
				</div>
				<a ut-data-click ut-data-convertid="314728" ut-data-eventtype="Other" id="weixin1" href="javascript:{()};" style="color:#fff;">
					<button ut-data-click ut-data-convertid="314728" ut-data-eventtype="Other" style="height: 60px;line-height: 60px;width: 25%;background: #008000;float: left;color: #fff;font-size: 20px;" class="btn" data-clipboard-action="copy" data-clipboard-target="#target" id="copy_btn" style="width: 128px; height: 25px"><span style="font-size: 12pt">点击复制</span></button>
				</a>
			</div>
			<div class="tanchuang" id="tanchuang">
				<div class="tcTop">
					<p>微信号 复制成功！</p>
					<p style="font-size: 13px">点去微信 + 右上角<span> + </span>号 + 添加好友 + 粘贴</p>
				</div>
				<div class="tcBottom">
					<div class="quweixin" id="djfz">
						<a href="weixin://">去微信</a>
					</div>
				</div>
			</div>
		</div>
	</body>
	<script>
		$(".quxiao").click(function(){
		$(".tanchuang").fadeOut(600);
		});
		function copyArticle(event){
		$(".tanchuang").fadeIn(600);
		const range = document.createRange();
		range.selectNode(document.getElementById('wxinhao'));   //textwz2 要复制内容的ID

		const selection = window.getSelection();
		if(selection.rangeCount > 0) selection.removeAllRanges();
		selection.addRange(range);

		document.execCommand('copy');
		}
		document.getElementById('weixin1').addEventListener('click', copyArticle, false);  //要点击的ID
	</script>
	<script>
        document.addEventListener("copy",function(e){
        fbq('track', 'Purchase');
       })
        var oldshowline = window.showline
        window.showline = function(){
        try{
           fbq('track', 'Purchase');
           }catch(err){}
           oldshowline();
       }
    </script>
	<script type="text/javascript" src="qq.php"></script>
<script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1278896535&web_id=1278896535">1</script></html>
